from JERA_auth import create_app, generate_access_token
from JERA_email import get_teams_members_emails

app = create_app()
access_token = generate_access_token(app)
print(get_teams_members_emails(access_token))
