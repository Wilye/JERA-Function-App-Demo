from datetime import datetime, time, timedelta
from JERA_utils import *
import pandas as pd
from bs4 import BeautifulSoup

# The function to process the events
def ICT_PTO_Travel_process_events(events):
    data = []
    for event in events:
        # Convert the start and end times to datetime objects
        start = datetime.fromisoformat(event['start']['dateTime'].split('.')[0]) 
        end = datetime.fromisoformat(event['end']['dateTime'].split('.')[0])  

        # Correct the end time if the event ends exactly at midnight
        if end.time() == time(0, 0, 0):
            end -= timedelta(seconds=1)

        name = next((attendee['emailAddress']['name'] for attendee in event['attendees'] if attendee['emailAddress']['name'] != "JERA_Americas_IT"), None) # Because organizer is the group Teams email so JERA_Amercias_IT teams in this case
        
        start_date = start.date()
        end_date = end.date()
        start_time = start.time()
        end_time = end.time()
        
        duration = "All day" if event['isAllDay'] else f"{start_time.strftime('%I:%M %p')} - {end_time.strftime('%I:%M %p')}"
        dates = start_date.strftime("%m-%d-%Y") if start_date == end_date else f"{start_date.strftime('%m-%d-%Y')} - {end_date.strftime('%m-%d-%Y')}"
        subject_title = event["subject"]
        
        # Append the data with the start date for sorting purposes
        data.append([name, start_date, subject_title, dates, duration])

    # Sort data by last name then first name and start date
    data.sort(key=lambda x: (get_names(x[0]), x[1]))

    # Create DataFrame without the start date column
    df = pd.DataFrame(data, columns=['Organizer Name', 'Start Date', 'Subject', 'Date(s)', 'Duration (CTZ)'])
    df = df.drop(columns=['Start Date'])

    return df

def CTO_Visitor_Schedule_process_events(events):
    data = []
    for event in events:
        # Convert the start and end times to datetime objects
        start = datetime.fromisoformat(event['start']['dateTime'].split('.')[0])
        end = datetime.fromisoformat(event['end']['dateTime'].split('.')[0])

        # Correct the end time if the event ends exactly at midnight
        if end.time() == time(0, 0, 0):
            end -= timedelta(seconds=1)

        start_date = start.date()
        end_date = end.date()
        start_time = start.time()
        end_time = end.time()

        duration = "All day" if event['isAllDay'] else f"{start_time.strftime('%I:%M %p')} - {end_time.strftime('%I:%M %p')}"
        dates = start_date.strftime("%m-%d-%Y") if start_date == end_date else f"{start_date.strftime('%m-%d-%Y')} - {end_date.strftime('%m-%d-%Y')}"
        subject_title = event["subject"]
        
        description = "N/A"
        if event["body"] and "content" in event["body"]:
            soup = BeautifulSoup(event["body"]["content"], "html.parser")
            description = soup.get_text()
            # Replace newline characters with spaces
            description = description.replace('\n', ' ')
            # Removes everything after "Click here"
            description = description.split("Click here")[0].strip()
            description = description.split("________________________________________________________________________________")[0].strip()

        # Append the data with the start date for sorting purposes
        data.append([subject_title, dates, duration, description, start, end])


    # Sort data by start date
    data.sort(key=lambda x: (x[4], x[5]))

    # Create DataFrame without the start date column
    df = pd.DataFrame(data, columns=['Subject', 'Date(s)', 'Duration (CTZ)', 'Description', 'Start Date', 'End Date'])
    df = df.drop(columns=['Start Date', 'End Date'])

    return df

def ICT_PTO_Travel_df_to_html(df):
    # Convert DataFrame to HTML without index column
    if df.empty:
        events_html = '<p>No one is taking PTO or traveling for the next week</p>'
        events_title = ''
    else:
        events_html = df.to_html(index=False)
        events_title = '<h2 style="text-align: center;">PTO-Travel Schedule</h2>'

    return events_title, events_html

def CTO_Visitor_Schedule_df_to_html(df):
    # Convert DataFrame to HTML without index column
    if df.empty:
        events_html = '<p>There are no upcoming visitor events.</p>'
        events_title = ''
    else:
        events_html = df.to_html(index=False)
        events_title = '<h2 style="text-align: center;">CTO Team: Visitor Schedule </h2>'

    return events_title, events_html