from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

schedule_set = {"weekly", "biweekly", "bimonthly"}

def start_and_end_of_time_frame(time_frame):
    if time_frame not in ["weekly", "biweekly", "bimonthly"]:
        raise ValueError(f"{time_frame} is not a valid time frame, the valid time frames are {'weekly', 'biweekly', 'bimonthly'}")

    if time_frame == "weekly":
        weeks = 1
        days = 6
    elif time_frame == "biweekly":
        weeks = 2
        days = 13
    elif time_frame == "bimonthly":
        weeks = 0
        days = 0
    
    if time_frame == "bimonthly":
        # Start from the beginning of the current month
        start_of_time_frame = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        # End at the last day of the next month
        end_of_time_frame = start_of_time_frame + relativedelta(months=2) - timedelta(days=1)
        end_of_time_frame = end_of_time_frame.replace(hour=23, minute=59, second=59)
    else:
        start_of_time_frame = datetime.now() + timedelta(days=-datetime.now().weekday(), weeks=weeks)
        start_of_time_frame = start_of_time_frame.replace(hour=0, minute=0, second=0, microsecond=0)
        end_of_time_frame = start_of_time_frame + timedelta(days=days)
        end_of_time_frame = end_of_time_frame.replace(hour=23, minute=59, second=59)

    return start_of_time_frame, end_of_time_frame

    return start_of_time_frame, end_of_time_frame

def start_and_end_of_next_time_frame(time_frame):
    if time_frame not in schedule_set:
        raise ValueError(f"{time_frame} is not a valid time frame, the valid time frames are {schedule_set}")
    
    start_of_time_frame, end_of_time_frame = start_and_end_of_time_frame(time_frame)

    if time_frame == "weekly":
        next_start_time_frame = start_of_time_frame + timedelta(weeks=1)
        next_end_time_frame = end_of_time_frame + timedelta(weeks=1)
    elif time_frame == "biweekly":
        next_start_time_frame = start_of_time_frame + timedelta(weeks=2)
        next_end_time_frame = end_of_time_frame + timedelta(weeks=2)
    elif time_frame == "bimonthly":
        next_start_time_frame = start_of_time_frame + relativedelta(months=1)
        next_end_time_frame = end_of_time_frame + relativedelta(months=1)

    return next_start_time_frame, next_end_time_frame

def get_names(name):
    names = name.split()
    first_name = names[0].lower() if len(names) > 0 else ''
    last_name = names[-1].lower() if len(names) > 1 else ''
    return last_name, first_name