import requests

def get_teams_members_emails(access_token, group_id):
    teams_members_graph_url = f"https://graph.microsoft.com/v1.0/groups/{group_id}/members"
    headers = {
            'Authorization': f'Bearer {access_token}',
            'Prefer': 'outlook.timezone="Central Standard Time"'
    }  
    response_teams_members = requests.get(teams_members_graph_url, headers=headers) 
    members = response_teams_members.json()['value']
    
    emails = []
    for member in members:
        email = member.get("mail")
        if email:  # If the email is not None or empty
            emails.append(email)

    return emails

def send_email(access_token, recipients, subject, html_body):
    url = "https://graph.microsoft.com/v1.0/me/sendMail"
    headers = {
        'Authorization' : 'Bearer ' + access_token,
        'Content-Type'  : 'application/json'
    }
    
    # Prepare the email body
    email_body = {
    "message": {
        "subject": subject,
        "body": {
            "contentType": "HTML",
            "content": html_body
        },
        "toRecipients": recipients
    },
    "saveToSentItems": "true"
    }

    # Send the email
    response = requests.post(url, headers=headers, json=email_body)

    # Check the response
    if response.status_code == 202:
        print("Email sent successfully!")
    else:
        print(f"Email not sent. Status code: {response.status_code}, Error: {response.text}")

def get_recipients(access_token):
    emails = get_teams_members_emails(access_token)

    # If you want to manually input emails, uncomment the list below and modify the recipients list to your liking
    """
     emails = ["shelby.yang_intern@jeraamericas.com",
              "daniel.owen@jeraamericas.com",
              "ashish.upadhyay@jeraamericas.com",
              "asuka.tarutani@jeraamericas.com",
              "bruce.otte@jeraamericas.com",
              "sayuri.onoda@jeraamericas.com",
              "ryan.elms@jeraamericas.com",
              "sridhar.mantri@jeraamericas.com",
              "keith.quigley@jeraamericas.com",
              "scott.phillips@jeraamericas.com",
              "mariko.ikeda@jeraamericas.com",
              "carlos.lopez@jeraamericas.com",
              "ankita.pandey@jeraamericas.com",
              "ritesh.choudhary_multicloud4u@jeraamericas.com",
              "paul.limon@jeraamericas.com",
              "ankit.gupta@jeraamericas.com",
              "henry.mokoko@jeraamericas.com",
              "kai.kurosawa@jeraamericas.com",
              "junko.janvier@jeraamericas.com",
              "rika.matsuura@jeraamericas.com",
              "kelly.hansard@jeraamericas.com"]
    """
    # emails = ["shelby.yang_intern@jeraamericas.com"]
    recipients = [{"emailAddress": {"address": email}} for email in emails]
    return recipients