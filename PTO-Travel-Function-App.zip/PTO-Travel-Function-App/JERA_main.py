from JERA_auth import create_app, generate_access_token
from JERA_data_processing import get_channel_messages, get_exchange_ids, get_calendar_events 
from JERA_events_processing import ICT_PTO_Travel_process_events, CTO_Visitor_Schedule_process_events, ICT_PTO_Travel_df_to_html, CTO_Visitor_Schedule_df_to_html
from JERA_email import get_recipients, send_email
from JERA_configurations_class import Teams_Automation_Configuration, ict_config, cto_config
from JERA_utils import start_and_end_of_time_frame, start_and_end_of_next_time_frame

def JERA_main(config: Teams_Automation_Configuration):
    print("here in main!")

    # Parameters for the Team, channel, token cache, and time_frame
    group_id = config.group_id
    channel_id = config.channel_id
    token_cache_file_name = config.token_cache_file_name
    time_frame = config.time_frame
    style = config.style
    body = config.body_template
    subject = config.style

    # Setting up app
    app = create_app()
    access_token = generate_access_token(app, token_cache_file_name)

    # Collecting events data
    messages = get_channel_messages(access_token, group_id, channel_id)
    exchange_ids = get_exchange_ids(messages, access_token, group_id, time_frame)
    calendar_events = get_calendar_events(exchange_ids, access_token, group_id)

    # Create table
    events_dataframe = process_events(config, calendar_events)
    events_html = df_to_html(config, events_dataframe)

    # Setting up email parameters for the dates in the subject and body
    start_of_time_frame, end_of_time_frame = start_and_end_of_time_frame(time_frame)
    next_start_time_frame, next_end_time_frame = start_and_end_of_next_time_frame(time_frame)

    variables = {
        'start_date': start_of_time_frame.strftime("%m/%d/%Y"),
        'end_date': end_of_time_frame.strftime("%m/%d/%Y"),
        'next_start_date': next_start_time_frame.strftime("%m/%d/%Y"),
        'next_end_date': next_end_time_frame.strftime("%m/%d/%Y"),
    }

    subject_template = config.subject_template 
    body_template = config.body_template
    subject = subject_template.format(**variables) # So, whenever {start_date} appears in the string, it will be replaced by the value of the variable 'start_date' in the variables dictionary. Same applies for other variables.
    body = body_template.format(**variables)

    # Email preparation and sending
    recipients = get_recipients(access_token)
    combined_html = style + body + events_html[0] + events_html[1]

    send_email(access_token, recipients, subject, combined_html)

def process_events(config: Teams_Automation_Configuration, calendar_events):
    # Determine the appropriate function to call based on the configuration
    if config.processing_type == 'ICT_PTO_Travel':
        return ICT_PTO_Travel_process_events(calendar_events)
    elif config.processing_type == 'CTO_Visitor_Schedule':
        return CTO_Visitor_Schedule_process_events(calendar_events)
    else:
        raise ValueError(f"Unknown processing type: {config.processing_type}")

def df_to_html(config: Teams_Automation_Configuration, dataframe):
    if config.processing_type == 'ICT_PTO_Travel':
        return ICT_PTO_Travel_df_to_html(dataframe)
    elif config.processing_type == 'CTO_Visitor_Schedule':
        return CTO_Visitor_Schedule_df_to_html(dataframe)
    else:
        raise ValueError(f"Unknown processing type: {config.processing_type}")

"""
# For running the script locally, uncomment the below if statement and run this JERA_main file
if __name__ == '__main__':
    JERA_main(cto_config)
"""
