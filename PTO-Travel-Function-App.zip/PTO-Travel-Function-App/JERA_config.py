client_id = '83bea295-884a-4909-9293-a49bb07a0edb'
client_secret = '_ws8Q~nYQ-Gd0kCQHmCCZ..9aVeDrZ7ab5W.haEA'
tenant_id = '2840389b-0f81-496f-b742-ac794a5da61e'

