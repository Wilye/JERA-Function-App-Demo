import requests

from ICT_PTO.JERA_auth import create_app, generate_access_token

app = create_app()
access_token = generate_access_token(app)
graph_url = "https://graph.microsoft.com/v1.0/me/people"
headers={
    'Authorization': f'Bearer {access_token}'
}
response = requests.get(graph_url, headers=headers)
response.raise_for_status()
print(response.json)