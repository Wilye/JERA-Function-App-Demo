class Teams_Automation_Configuration:
    def __init__(self, group_id, channel_id, token_cache_file_name, time_frame, subject_template, body_template, style, processing_type):
        self.group_id = group_id
        self.channel_id = channel_id
        self.token_cache_file_name = token_cache_file_name
        self.time_frame = time_frame
        self.subject_template = subject_template
        self.body_template = body_template
        self.style = style
        self.processing_type = processing_type

ict_config = Teams_Automation_Configuration(
    group_id='9717b8b0-c079-4946-a99b-3cae873d321e',
    channel_id='19%3a487f4479c76746ceaae6b24b89c7a2c4%40thread.tacv2',
    token_cache_file_name="ICT_PTO_Travel_token_cache.pkl",
    time_frame="weekly",
    subject_template="{start_date} - {end_date} PTO and Travel Schedule Information",
    body_template="""
    <p>Hello ICT department,</p>

    <p>This is a friendly reminder that you are expected to log your PTO and travel schedule to share with this team in the PTO-Travel channel on Microsoft Teams in the JERA Americas_IT Teams in advance.</p>

    <p>By the end of today Friday, please make sure that you have logged your PTO and travel time that you will begin to take from {next_start_date} - {next_end_date} on the <a href="https://teams.microsoft.com/l/channel/19%3a487f4479c76746ceaae6b24b89c7a2c4%40thread.tacv2/PTO-%2520Travel?groupId=9717b8b0-c079-4946-a99b-3cae873d321e&tenantId=2840389b-0f81-496f-b742-ac794a5da61e">PTO-Travel channel calendar</a>.</p>

    <p>Thank you very much for your contributions.</p>

    <p>The list below is the recommended or required other action item to prepare for your time off:</p>

    <ul>
        <li>Request time off from TimeClock.</li>
        <li>Cancel meetings that you organize or let the team know you can’t attend if needed.</li>
        <li>Set automatic replies in outlook if needed.</li>
        <li>Block your calendar by creating an all-day appointment with OOO mode so you don’t get new meeting invites during the time if needed.</li>
    </ul>

    <p>Here is the list of people taking time off and/or travelling in the upcoming week ({start_date} - {end_date}):</p>
    """,
    style="""<style>
        body {
            font-family: Calibri, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 100%;    
        }
        th, td, h2 {
            text-align: center;
        }
    </style>
    """,
    processing_type='ICT_PTO_Travel' # This determines which parameters the algorithm should filter for, so the ICT_PTO_Travel processing type finds the name of the organizer, the subject title, the dates, and the duration  
)

cto_config = Teams_Automation_Configuration(
    group_id='456ff9b5-87d0-4ee9-af97-473b5b3a80e3',
    channel_id='19%3a255a321782e6489f83ecfef48793fbba%40thread.tacv2',
    token_cache_file_name='CTO_Visitor_Schedule_token_cache.pkl',
    time_frame="bimonthly",
    subject_template="Visitor Schedule Update - CTO Department",
    body_template="""<p>Hello CTO team members,</p>

    <p>A Department Calendar has been created for the CTO team on Microsoft Teams in order for CTO team members to have better visibility of special events and visitors.</p>

    <p>This is a friendly reminder that, if you are planning to receive special visitor(s) such as people from HQ, plant visits (Linden, Canal, El Sauz, Cricket, etc.), and other important meetings which you would like to share with CTO team, please add them to the <a href="https://teams.microsoft.com/l/channel/19%3A255a321782e6489f83ecfef48793fbba%40thread.tacv2/tab%3A%3A78d08e33-d7f9-44bf-9dec-7d82b9ec775d?groupId=456ff9b5-87d0-4ee9-af97-473b5b3a80e3&tenantId=2840389b-0f81-496f-b742-ac794a5da61e&allowXTenantAccess=false">Department Calendar</a> channel of the JERA Americas Construction and Assets on Microsoft Teams.</p>

    <p>Note that you are not required to input your daily activities, including ordinary meetings.</p>

    <p>Please make sure that you add a schedule of hosting visitor(s) to the Department Calendar from this <a href="https://teams.microsoft.com/l/channel/19%3A255a321782e6489f83ecfef48793fbba%40thread.tacv2/tab%3A%3A78d08e33-d7f9-44bf-9dec-7d82b9ec775d?groupId=456ff9b5-87d0-4ee9-af97-473b5b3a80e3&tenantId=2840389b-0f81-496f-b742-ac794a5da61e&allowXTenantAccess=false">Teams Link</a> or email Mizue and/or Kallie to add a new event on your behalf by the end of the day (Friday).</p>

    <p>Thank you very much for your contributions.</p>

    <p>Here is the list of CTO team visitors in the current month and upcoming month:</p>""",
    style="""<style>
        body {
            font-family: Calibri, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 100%;    
        }
        th, td, h2 {
            text-align: center;
        }
    </style>
    """,   
    processing_type='CTO_Visitor_Schedule'
)